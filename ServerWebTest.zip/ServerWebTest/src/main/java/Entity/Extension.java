/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author alex_
 */
@Entity
@Table(name = "extension")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Extension.findAll", query = "SELECT e FROM Extension e")})
public class Extension implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idextension")
    private Integer idextension;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "libelle_extension")
    private String libelleExtension;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idextension")
    private Collection<PieceJointe> pieceJointeCollection;

    public Extension() {
    }

    public Extension(Integer idextension) {
        this.idextension = idextension;
    }

    public Extension(Integer idextension, String libelleExtension) {
        this.idextension = idextension;
        this.libelleExtension = libelleExtension;
    }

    public Integer getIdextension() {
        return idextension;
    }

    public void setIdextension(Integer idextension) {
        this.idextension = idextension;
    }

    public String getLibelleExtension() {
        return libelleExtension;
    }

    public void setLibelleExtension(String libelleExtension) {
        this.libelleExtension = libelleExtension;
    }

    @XmlTransient
    public Collection<PieceJointe> getPieceJointeCollection() {
        return pieceJointeCollection;
    }

    public void setPieceJointeCollection(Collection<PieceJointe> pieceJointeCollection) {
        this.pieceJointeCollection = pieceJointeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idextension != null ? idextension.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Extension)) {
            return false;
        }
        Extension other = (Extension) object;
        if ((this.idextension == null && other.idextension != null) || (this.idextension != null && !this.idextension.equals(other.idextension))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Extension[ idextension=" + idextension + " ]";
    }
    
}
