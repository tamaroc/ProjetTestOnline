/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author alex_
 */
@Entity
@Table(name = "mot_cle")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MotCle.findAll", query = "SELECT m FROM MotCle m")})
public class MotCle implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idmot_cle")
    private Integer idmotCle;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "libelle_mot_cle")
    private String libelleMotCle;
    @JoinColumn(name = "idpiece_jointe", referencedColumnName = "idpiece_jointe")
    @ManyToOne(optional = false)
    private PieceJointe idpieceJointe;

    public MotCle() {
    }

    public MotCle(Integer idmotCle) {
        this.idmotCle = idmotCle;
    }

    public MotCle(Integer idmotCle, String libelleMotCle) {
        this.idmotCle = idmotCle;
        this.libelleMotCle = libelleMotCle;
    }

    public Integer getIdmotCle() {
        return idmotCle;
    }

    public void setIdmotCle(Integer idmotCle) {
        this.idmotCle = idmotCle;
    }

    public String getLibelleMotCle() {
        return libelleMotCle;
    }

    public void setLibelleMotCle(String libelleMotCle) {
        this.libelleMotCle = libelleMotCle;
    }

    public PieceJointe getIdpieceJointe() {
        return idpieceJointe;
    }

    public void setIdpieceJointe(PieceJointe idpieceJointe) {
        this.idpieceJointe = idpieceJointe;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idmotCle != null ? idmotCle.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MotCle)) {
            return false;
        }
        MotCle other = (MotCle) object;
        if ((this.idmotCle == null && other.idmotCle != null) || (this.idmotCle != null && !this.idmotCle.equals(other.idmotCle))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.MotCle[ idmotCle=" + idmotCle + " ]";
    }
    
}
