/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreType;
import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author alex_
 */
@Entity
@Table(name = "dossier")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Dossier.findAll", query = "SELECT d FROM Dossier d")})
public class Dossier implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "iddossier")
    private Integer iddossier;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "libelle_dossier")
    private String libelleDossier;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "iddossier")
    private Collection<PieceJointe> pieceJointeCollection;
    @JoinColumn(name = "idstatut", referencedColumnName = "idstatut")
    @ManyToOne(optional = false)
    private Statut idstatut;
    @JoinColumn(name = "idutilisateur", referencedColumnName = "idutilisateur")
    @ManyToOne(optional = false)
    private Utilisateur idutilisateur;

    public Dossier() {
    }

    public Dossier(Integer iddossier) {
        this.iddossier = iddossier;
    }

    public Dossier(Integer iddossier, String libelleDossier) {
        this.iddossier = iddossier;
        this.libelleDossier = libelleDossier;
    }

    public Integer getIddossier() {
        return iddossier;
    }

    public void setIddossier(Integer iddossier) {
        this.iddossier = iddossier;
    }

    public String getLibelleDossier() {
        return libelleDossier;
    }

    public void setLibelleDossier(String libelleDossier) {
        this.libelleDossier = libelleDossier;
    }

    @XmlTransient
    public Collection<PieceJointe> getPieceJointeCollection() {
        return pieceJointeCollection;
    }

    public void setPieceJointeCollection(Collection<PieceJointe> pieceJointeCollection) {
        this.pieceJointeCollection = pieceJointeCollection;
    }

    public Statut getIdstatut() {
        return idstatut;
    }

    public void setIdstatut(Statut idstatut) {
        this.idstatut = idstatut;
    }

    public Utilisateur getIdutilisateur() {
        return idutilisateur;
    }

    public void setIdutilisateur(Utilisateur idutilisateur) {
        this.idutilisateur = idutilisateur;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iddossier != null ? iddossier.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Dossier)) {
            return false;
        }
        Dossier other = (Dossier) object;
        if ((this.iddossier == null && other.iddossier != null) || (this.iddossier != null && !this.iddossier.equals(other.iddossier))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Dossier[ iddossier=" + iddossier + " ]";
    }
    
}
